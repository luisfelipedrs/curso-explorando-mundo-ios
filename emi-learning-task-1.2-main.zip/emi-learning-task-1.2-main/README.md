# emi-learning-task-1.2
Explorando o Mundo iOS - Learning Task 1.2
