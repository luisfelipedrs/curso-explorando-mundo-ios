//
//  TreinoTableViewCell.swift
//  LearningTask-10.2
//
//  Created by Luis Felipe on 29/11/22.
//

import UIKit

class TreinoTableViewCell: UITableViewCell {

    @IBOutlet weak var simboloLabel: UILabel!
    @IBOutlet weak var tituloLabel: UILabel!
    @IBOutlet weak var descricaoLabel: UILabel!
    
    var treino: Treino? {
        didSet {
            guard let treino = treino else { return }
            
            simboloLabel.text = treino.simbolo
            tituloLabel.text = treino.titulo
            descricaoLabel.text = treino.descricao
        }
    }
}
