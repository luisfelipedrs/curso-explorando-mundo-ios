//
//  ExercicioTableViewCell.swift
//  LearningTask-10.2
//
//  Created by Luis Felipe on 29/11/22.
//

import UIKit

class ExercicioTableViewCell: UITableViewCell {
    
    @IBOutlet weak var simboloLabel: UILabel!
    @IBOutlet weak var nomeLabel: UILabel!
    @IBOutlet weak var descricaoLabel: UILabel!
    
    var exercicio: Exercicio? {
        didSet {
            guard let exercicio = exercicio else { return }
            
            simboloLabel.text = exercicio.simbolo
            nomeLabel.text = exercicio.nome
            descricaoLabel.text = exercicio.descricao
        }
    }
    
}
