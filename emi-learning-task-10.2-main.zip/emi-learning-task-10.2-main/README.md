# emi-learning-task-10.2
Explorando o Mundo iOS - Learning Task 10.2
