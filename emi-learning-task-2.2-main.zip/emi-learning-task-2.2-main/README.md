# emi-learning-task-2.2
Explorando o Mundo iOS - Learning Task 2.2
