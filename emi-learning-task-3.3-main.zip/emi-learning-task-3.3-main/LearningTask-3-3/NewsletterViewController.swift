//
//  NewsletterViewController.swift
//  LearningTask-3-3
//
//  Created by Luis Felipe on 17/10/22.
//

import UIKit

class NewsletterViewController: UIViewController {

    @IBOutlet weak var emailTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func botaoConfirmarPressionado(_ sender: UIButton) {
        exibeAlertaDeConfirmacao()
    }
    
    func exibeAlertaDeConfirmacao() {
        let titulo = "Confirmar"
        let mensagem = "Confirmar inscrição para o email \(emailTextField.text!)?"
        
        // let alert = UIAlertController(title: "Tudo pronto!", message: "Email \(emailTextField.text!) cadastrado com sucesso.\nEm breve você começará a receber oportunidades imperdíveis.", preferredStyle: .alert)
        
        let alert = UIAlertController(title: titulo, message: mensagem, preferredStyle: .actionSheet)
        
        alert.addAction(UIAlertAction(title: "Confirmar", style: .default, handler: nil))
        alert.addAction(UIAlertAction(title: "Cancelar", style: .cancel, handler: nil))
        
        self.present(alert, animated: true, completion: nil)
    }
}
