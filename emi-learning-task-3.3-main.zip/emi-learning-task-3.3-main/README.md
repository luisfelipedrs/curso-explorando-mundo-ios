# emi-learning-task-3.3
Explorando o Mundo iOS - Learning Task 3.3

## Siga os passos para concluir o trabalho

Vamos exercitar mais uma vez o conteúdo aprendido até aqui. Siga os passos de Rafael para concluir o trabalho e chegar ao objetivo para a especificação de funcionalidade simples abaixo.

![Imagem com a especificação alvo para a funcionalidade](https://github.com/zup-academy/materiais-publicos-treinamentos/blob/main/explorando-o-mundo-ios/imagens/primeiros-comportamentos-lt3-especificacao-alvo.jpg?raw=true)

*Especificação da funcionalidade simples*

![Imagem com as especificações de design por cada componente para a implementação do desafio](https://github.com/zup-academy/materiais-publicos-treinamentos/blob/main/explorando-o-mundo-ios/imagens/primeiros-comportamentos-lt3-especificacao-de-design.jpg?raw=true)

Assista ao vídeo abaixo onde o especialista mostra um passo a passo para a construção da funcionalidade. Na sequência implemente você mesmo a partir do projeto base disponível [neste repositório](https://github.com/rafaelrollozup/emi-learning-task-3.3).

[Clique aqui](https://youtu.be/9kFO1pfndCE) para assistir ao vídeo.
