resolução da tarefa 3.4 do curso Explorando o Mundo iOS
