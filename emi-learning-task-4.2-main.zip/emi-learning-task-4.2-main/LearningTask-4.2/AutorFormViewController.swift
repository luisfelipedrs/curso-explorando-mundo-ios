//
//  ViewController.swift
//  LearningTask-4.2
//
//  Created by rafael.rollo on 17/02/2022.
//

import UIKit

class AutorFormViewController: UIViewController {
    
    typealias MensagemDeValidacao = String
    
    @IBOutlet weak var fotoTextField: UITextField!
    @IBOutlet weak var nomeTextField: UITextField!
    @IBOutlet weak var bioTextField: UITextField!
    @IBOutlet weak var techTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func botaoSalvarPressionado(_ sender: Any) {
        
        switch formularioValido() {
            
        case (false, let MensagemDeValidacao):
            
            if let mensagemDeValidacao = MensagemDeValidacao {
                let titulo = "Erro"
                exibirAlerta(titulo, mensagemDeValidacao)
            }
        
        default:
            cadastrarUsuario()
        }
    }
    
    func formularioValido() -> (Bool, MensagemDeValidacao?) {
        
        if let fotoInput = fotoTextField.text, fotoInput.isEmpty {
            return (false, "Informe a URL da foto do autor")
        }
        
        if let nomeInput = nomeTextField.text, nomeInput.isEmpty {
            return (false, "Nome não pode estar em branco")
        }
        
        if let bioInput = bioTextField.text, bioInput.isEmpty {
            return (false, "Bio não pode estar em branco")
        }
        
        if let techInput = techTextField.text, techInput.isEmpty {
            return (false, "Tecnologias não pode estar em branco")
        }
        
        return (true, nil)
    }
    
    func cadastrarUsuario() {
        
        exibirAlerta("Feito", "Autor cadastrado com sucesso")
        
    }
    
    func exibirAlerta(_ titulo: String, _ mensagem: String) {
        
        let alert = UIAlertController(title: titulo, message: mensagem, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .cancel))
        self.present(alert, animated: true)
    }
}
