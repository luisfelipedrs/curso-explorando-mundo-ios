# emi-learning-task-4.2
Explorando o Mundo iOS - Learning Task 4.2
