//
//  ViewController.swift
//  LearningTask-4.3
//
//  Created by rafael.rollo on 16/02/2022.
//

import UIKit

class LoginViewController: UIViewController {
    
    typealias MensagemDeValidacao = String
    
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var senhaTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func botaoLoginPressionado(_ sender: UIButton) {
        
        switch validarLogin() {
            
        case(false, let mensagemDeValidacao):
            exibirAlerta("Ops", mensagemDeValidacao)
            
        default:
            exibirAlerta("Logando", "Fazendo login na sua conta...")
        }
    }
    
    @IBAction func botaoSenhaPressionado(_ sender: UIButton) {
        
        guard validarEmail() else {
            exibirAlerta("Ops", "Informe seu email e tente novamente")
            return
        }
        
        exibirAlerta("Redefinir senha", "Enviamos um email para \(emailTextField.text!).\nSiga as instruções para criar uma nova senha.")
    }
    
    func validarEmail() -> Bool {
        
        guard let email = emailTextField.text, !email.isEmpty else {
            return false
        }
        
        return true
    }
    
    func validarSenha() -> Bool {
        
        guard let senha = senhaTextField.text, !senha.isEmpty else {
            return false
        }
        
        return true
    }
    
    func validarLogin() -> (Bool, MensagemDeValidacao?) {
        
        guard validarEmail() else {
            return (false, "Email não pode estar em branco")
        }
        
        guard validarSenha() else {
            return (false, "Senha não pode estar em branco")
        }
        
        return (true, nil)
    }
    
    func logarUsuario() {
        
        exibirAlerta("Logando", "Fazendo login na sua conta...")
    }
    
    func exibirAlerta(_ titulo: String, _ mensagem: String?) {
        
        let alert = UIAlertController(title: titulo, message: mensagem, preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: "Ok", style: .default))
        
        self.present(alert, animated: true)
    }
}
