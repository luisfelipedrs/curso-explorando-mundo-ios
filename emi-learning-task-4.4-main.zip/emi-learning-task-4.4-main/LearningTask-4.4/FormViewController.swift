//
//  ViewController.swift
//  LearningTask-4.4
//
//  Created by rafael.rollo on 15/02/2022.
//

import UIKit

class FormViewController: UIViewController {
    
    typealias MensagemDeValidacao = String

    @IBOutlet weak var nomeTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var areaAtuacaoTextField: UITextField!
    @IBOutlet weak var statusProfissionalTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func botaoSubmissaoPressionado(_ sender: UIButton) {
        
        switch validarCampos() {
            
        case (false, let mensagem):
            exibeAlertaDeErro(para: mensagem)
            
        default:
            exibeAlertaDeRevisao()
        }
    }
    
    func validarCampos() -> (Bool, MensagemDeValidacao?){
        
        guard let nome = nomeTextField.text, !nome.isEmpty else {
            return (false, "Nome não pode estar em branco.")
        }
        
        guard let email = emailTextField.text, !email.isEmpty else {
            return (false, "Email não pode estar em branco.")
        }
        
        guard let areaAtuacao = areaAtuacaoTextField.text, !areaAtuacao.isEmpty else {
            return (false, "Informe sua área de atuação.")
        }
        
        guard let statusProfissional = statusProfissionalTextField.text, !statusProfissional.isEmpty else {
            return (false, "Informe seu status profissinal.")
        }
        
        guard validarEmail(email: email) else {
            return (false, "O email informado é inválido.")
        }
        
        return (true, nil)
    }
    
    func validarEmail(email: String) -> Bool {
        
        let emailRegex = "^[\\p{L}0-9!#$%&'*+\\/=?^_`{|}~-][\\p{L}0-9.!#$%&'*+\\/=?^_`{|}~-]{0,63}@[\\p{L}0-9-]+(?:\\.[\\p{L}0-9-]{2,7})*$"
        
        let emailPredicate = NSPredicate(format: "SELF MATCHES %@", emailRegex)
        
        return emailPredicate.evaluate(with: email)
    }
    
    func exibeAlertaDeRevisao() {
        
        let mensagem = """
            Antes de enviarmos, por favor, revise seus dados:
        
            Nome: \(nomeTextField.text!)
            Email: \(emailTextField.text!)
            Área de Atuação: \(areaAtuacaoTextField.text!)
            Status Profissional: \(statusProfissionalTextField.text!)
        """
        
        let alert = UIAlertController(title: "Quase lá!", message: mensagem, preferredStyle: .actionSheet)
        
        alert.addAction(UIAlertAction(title: "Confirmar", style: .default, handler: acaoDeConfirmacaoDisparada))
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        
        self.present(alert, animated: true, completion: nil)
    }
    
    func acaoDeConfirmacaoDisparada(_ action: UIAlertAction) {
        
        exibeAlertaDeConfirmacao()
    }
    
    func exibeAlertaDeConfirmacao() {
        
        let alert = UIAlertController(title: "Feito!", message: "Verifique seu email e tenha acesso ao documento.", preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: "Ok!", style: .cancel, handler: nil))
        
        self.present(alert, animated: true, completion: nil)
    }

    func exibeAlertaDeErro(para mensagem: MensagemDeValidacao?) {
        
        let alert = UIAlertController(title: "Quase lá!", message: mensagem, preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: "Ok", style: .default))
        
        self.present(alert, animated: true)
    }
}
