# emi-learning-task-5.2
Explorando o Mundo iOS - Learning Task 5.2
