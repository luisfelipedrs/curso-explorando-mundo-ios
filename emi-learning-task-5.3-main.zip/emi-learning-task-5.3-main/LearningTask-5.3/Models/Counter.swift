//
//  File.swift
//  LearningTask-5.3
//
//  Created by Luis Felipe on 27/10/22.
//


import Foundation

struct Counter {
    private(set) var currentValue: Int = 0
    private(set) var incrementValue: Int = 1
    
    var colorName: String {
        if currentValue < 0 {
            return "Almond"
        }
        else {
            return "Satin Linen"
        }
    }
    
    mutating func add() {
        currentValue += incrementValue
    }
    
    mutating func sub() {
        currentValue -= incrementValue
    }
    
    mutating func reset() {
        self = Counter()
    }
    
    mutating func incrementValueDidChange(_ value: Int) {
        incrementValue = value
    }
}
