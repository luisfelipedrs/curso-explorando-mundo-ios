//
//  ViewController.swift
//  LearningTask-5.3
//
//  Created by rafael.rollo on 12/03/2022.
//

import UIKit

class CounterViewController: UIViewController {
    
    @IBOutlet var mainView: UIView!
    @IBOutlet weak var mainStackView: UIStackView!
    
    @IBOutlet weak var currentValueLabel: UILabel!
    @IBOutlet weak var incrementLabel: UILabel!
    @IBOutlet weak var stepper: UIStepper!
    
    var counter: Counter? {
        didSet {
            guard isViewLoaded, let counter = counter else { return }
            updateView(to: counter)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let counter = counter {
            updateView(to: counter)
        }
    }

    func updateView(to counter: Counter) {
        currentValueLabel.text = String(describing: counter.currentValue)
        incrementLabel.text = String(describing: counter.incrementValue)
        mainView.backgroundColor = UIColor(named: counter.colorName)
        mainStackView.backgroundColor = UIColor(named: counter.colorName)
    }
    
    @IBAction func didPressPlusButton(_ sender: UIButton) {
        counter?.add()
    }
    
    @IBAction func didPressMinusButton(_ sender: UIButton) {
        counter?.sub()
    }
    
    @IBAction func stepper(_ sender: UIStepper) {
        let value = Int(stepper.value)
        counter?.incrementValueDidChange(Int(stepper.value))
        incrementLabel.text = String(describing: value)
    }
    
    @IBAction func didPressResetButton(_ sender: UIButton) {
        stepper.value = 1
        counter?.reset()
    }
}
