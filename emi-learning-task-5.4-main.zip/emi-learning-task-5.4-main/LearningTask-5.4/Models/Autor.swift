//
//  Autor.swift
//  LearningTask-5.4
//
//  Created by Luis Felipe on 28/10/22.
//

import Foundation

struct Autor {
    
    var fotoURI: String?
    var nome: String?
    var sobrenome: String?
    var bio: String?
    var tecnologias: String?
    var nomeCompleto: String?
}
