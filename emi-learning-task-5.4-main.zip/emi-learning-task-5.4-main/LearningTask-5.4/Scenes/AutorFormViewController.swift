//
//  ViewController.swift
//  LearningTask-5.4
//
//  Created by rafael.rollo on 09/03/2022.
//

import UIKit

class AutorFormViewController: UIViewController {

    @IBOutlet weak var fotoTextField: UITextField!
    @IBOutlet weak var nomeTextField: UITextField!
    @IBOutlet weak var bioTextField: UITextField!
    @IBOutlet weak var tecnologiasTextField: UITextField!
    
    //var autor: Autor?
    var autorRepository = AutorRepository()
    
    typealias MensagemDeValidacao = String
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func botaoSalvarPressionado(_ sender: UIButton) {
        guard let foto = fotoTextField.text, !foto.isEmpty else {
            exibirAlertaDeErro(mensagemDeErro: "O campo Foto não pode estar vazio.")
            return
        }
        
        guard let nome = nomeTextField.text, !nome.isEmpty else {
            exibirAlertaDeErro(mensagemDeErro: "Nome não pode estar vazio.")
            return
        }
        
        guard let nome = nomeTextField.text, nomeDeAutorValido(nome) else {
            exibirAlertaDeErro(mensagemDeErro: "O campo Nome não é válido.")
            return
        }
        
        guard let bio = bioTextField.text, !bio.isEmpty else {
            exibirAlertaDeErro(mensagemDeErro: "Bio não pode estar vazio.")
            return
        }
        
        guard let tecnologias = tecnologiasTextField.text, !tecnologias.isEmpty else {
            exibirAlertaDeErro(mensagemDeErro: "Tecnologias não pode estar vazio.")
            return
        }
        
        let autor = Autor(fotoURI: foto, nome: nome, bio: bio, tecnologias: tecnologias)
        
        AutorRepository.salva(autor)
        
        print("go")
    }
    
    func nomeDeAutorValido(_ nome: String) -> Bool {
        let pattern = #"^[a-zA-Z-]+ ?.* [a-zA-Z-]+$"#
        return NSPredicate(format: "SELF MATCHES %@", pattern).evaluate(with: nome)
    }
    
    func formata(nomeDeAutor: String) -> (String, String) {
        let separador = " "
        let nomeCompleto = nomeDeAutor.components(separatedBy: separador)
        return (nomeCompleto.first!, nomeCompleto.dropFirst().joined(separator: separador))
    }
    
    func exibirAlertaDeErro(mensagemDeErro: MensagemDeValidacao?) {
        let alert = UIAlertController(title: "Erro!", message: mensagemDeErro, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
}
