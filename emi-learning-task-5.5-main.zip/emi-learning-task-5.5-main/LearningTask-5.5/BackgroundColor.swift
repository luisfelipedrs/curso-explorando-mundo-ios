
import UIKit

class BackgroundColor {
    
    static func para(_ bebida: DrinkGame.Bebida) -> UIColor {
        
        switch bebida {
            
        case .🥛:
            return UIColor(named: "Milk")!
            
        case .🍺:
            return UIColor(named: "Beer")!
            
        default:
            return UIColor(named: "Whisky")!
        }
    }
}
