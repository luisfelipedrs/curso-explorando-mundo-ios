//
//  DrinkGame.swift
//  LearningTask-5.5
//
//  Created by Luis Felipe on 28/10/22.
//

import UIKit
import Foundation

struct DrinkGame {
    
    var bebidaAnterior: String = "🙋"
    var bebidaAtual: String = "🥛"
    var backgroundColor: UIColor?
    
    enum Bebida: CaseIterable {
        case 🥛
        case 🍺
        case 🥃
    }
    
    mutating func play() {
        
        self.bebidaAnterior = bebidaAtual

        let bebidaAleatoria = Bebida.allCases.randomElement()
        
        switch bebidaAleatoria {
            
        case .🥛:
            self.bebidaAtual = "🥛"
            
        case .🍺:
            self.bebidaAtual = "🍺"
            
        default:
            self.bebidaAtual = "🥃"
        }
        self.backgroundColor = BackgroundColor.para(bebidaAleatoria!)
    }
}
