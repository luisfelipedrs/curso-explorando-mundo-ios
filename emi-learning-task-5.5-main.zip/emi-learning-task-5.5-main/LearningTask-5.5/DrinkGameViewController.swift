//
//  ViewController.swift
//  LearningTask-5.5
//
//  Created by rafael.rollo on 12/03/2022.
//

import UIKit

class DrinkGameViewController: UIViewController {

    @IBOutlet weak var bebidaAnteriorLabel: UILabel!
    @IBOutlet weak var bebidaAtualLabel: UILabel!
    
    var drinkGame: DrinkGame? {
        didSet {
            guard isViewLoaded, let drinkGame = drinkGame else { return }
            updateView(to: drinkGame)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func botaoPlayPressionado(_ sender: UIButton) {
        drinkGame?.play()
    }
    
    func updateView(to drinkGame: DrinkGame) {
        bebidaAnteriorLabel.text = drinkGame.bebidaAnterior
        bebidaAtualLabel.text = drinkGame.bebidaAtual
        view.backgroundColor.self = drinkGame.backgroundColor
    }
}

