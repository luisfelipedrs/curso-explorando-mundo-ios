//
//  Custom+UIColor.swift
//  LearningTask-6.2
//
//  Created by rafael.rollo on 19/04/2022.
//

import UIKit

extension UIColor {
    static var deepSea: UIColor? = .init(named: "Deep Sea")
}
