//
//  Session.swift
//  LearningTask-6.3
//
//  Created by Luis Felipe on 03/11/22.
//

import Foundation

struct Session {
    let dateTime: Date
    let type: SessionType
    let movie: Movie
    
    init(dateTime: Date, type: SessionType, movie: Movie) {
        self.dateTime = dateTime
        self.type = type
        self.movie = movie
    }
}

struct Sessions {
    var incomingSessions: [Session]
    var cinema: Cinema?
    
    init(_ incomingSessions: [Session], by cinema: Cinema) {
        self.incomingSessions = incomingSessions
        self.cinema = cinema
    }
}

enum SessionType {
    case dubbed
    case subtitled
    
    var language: String {
        switch self {
        case .dubbed:
            return "Dublado"
        case .subtitled:
            return "Legendado"
        }
    }
}
