//
//  MoviesTableViewController.swift
//  LearningTask-6.3
//
//  Created by Luis Felipe on 03/11/22.
//

import UIKit

class MoviesTableViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }

}
