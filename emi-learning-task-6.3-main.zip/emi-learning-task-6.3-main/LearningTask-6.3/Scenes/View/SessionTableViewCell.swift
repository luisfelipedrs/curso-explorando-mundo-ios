//
//  SessionTableViewCell.swift
//  LearningTask-6.3
//
//  Created by Luis Felipe on 03/11/22.
//

import UIKit

class SessionTableViewCell: UITableViewCell {

    
}
