//
//  ViewController.swift
//  LearningTask-6.4
//
//  Created by rafael.rollo on 12/04/2022.
//

import UIKit

class PokemonViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    var pokemonStore: PokemonStore?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setup()
    }
    
    func setup() {
        tableView.tableHeaderView = HeaderView.com(titulo: "Pokédex")
        tableView.dataSource = self
        tableView.delegate = self
    }
}

extension PokemonViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return pokemonStore?.todos.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "PokemonViewCell", for: indexPath) as? PokemonViewCell else {
            fatalError("não foi possível instanciar uma célula")
        }
        
        let pokemons = pokemonStore!.todos[indexPath.row]
        
        cell.setup(pokemons)
        return cell
    }
}

extension PokemonViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }
}
