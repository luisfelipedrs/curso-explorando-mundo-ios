//
//  PokemonViewCell.swift
//  LearningTask-6.4
//
//  Created by Luis Felipe on 04/11/22.
//

import UIKit

class PokemonViewCell: UITableViewCell {

    @IBOutlet weak var pokemonNameLabel: UILabel!
    @IBOutlet weak var pokemonEvolutionLabel: UILabel!
    @IBOutlet weak var pokemonTypeView: TipoDePokemonView!
    @IBOutlet weak var pokemonImageView: UIImageView!
    
    func setup(_ pokemon: Pokemon) {
        let evolucoesList = pokemon.evolucoes.map({ pokemon in pokemon.nome })
        
        pokemonNameLabel.text = pokemon.nome
        pokemonEvolutionLabel.text = evolucoesList.count == 0 ? "N/A" : evolucoesList.joined(separator: ", ")
        pokemonImageView.image = UIImage(named: pokemon.referencia)
        pokemonTypeView.set(pokemon.tipo)
    }
}
