# emi-learning-task-6.4
Explorando o Mundo iOS - Learning Task 6.4
