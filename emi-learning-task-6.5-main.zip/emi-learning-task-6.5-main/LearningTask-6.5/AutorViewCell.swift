//
//  AutorViewCell.swift
//  LearningTask-6.5
//
//  Created by Luis Felipe on 06/11/22.
//

import UIKit

class AutorViewCell: UITableViewCell {
    
    @IBOutlet weak var nomeLabel: UILabel!
    @IBOutlet weak var tecnologiasLabel: UILabel!
    
    func setup(to autor: Autor) {
        nomeLabel.text = autor.nomeCompleto
        tecnologiasLabel.text = autor.tecnologias.joined(separator: ", ")
    }
}
