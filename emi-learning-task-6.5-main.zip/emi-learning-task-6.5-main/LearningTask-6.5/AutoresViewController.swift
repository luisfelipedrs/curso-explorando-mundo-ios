//
//  ViewController.swift
//  LearningTask-6.5
//
//  Created by rafael.rollo on 12/04/2022.
//

import UIKit

class AutoresViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    var autorApi: AutorAPI?
    var autorList: [Autor]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
                
        setup()
        carregaAutores()
    }
    
    func setup() {
        tableView.dataSource = self
        tableView.delegate = self
    }
    
    func carregaAutores() {
        guard let autorApi = autorApi else { return }
        autorList = autorApi.listaTodos()
    }
}

extension AutoresViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "AutorViewCell", for: indexPath) as? AutorViewCell else {
            fatalError("não foi possível instanciar uma célula")
        }
        let autor = autorList![indexPath.row]
        cell.setup(to: autor)
        return cell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return autorList!.count
    }
}

extension AutoresViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }
}
