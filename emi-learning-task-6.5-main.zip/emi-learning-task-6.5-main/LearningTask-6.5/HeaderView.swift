//
//  HeaderView.swift
//  LearningTask-6.5
//
//  Created by Luis Felipe on 06/11/22.
//

import UIKit

class HeaderView: UIView {
    private lazy var 

}
