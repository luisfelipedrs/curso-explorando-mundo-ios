# emi-learning-task-6.5
Explorando o Mundo iOS - Learning Task 6.5
