//
//  Livro.swift
//  LearningTask-7.3
//
//  Created by Luis Felipe on 08/11/22.
//

import Foundation

struct Livro {
    let titulo: String
}
