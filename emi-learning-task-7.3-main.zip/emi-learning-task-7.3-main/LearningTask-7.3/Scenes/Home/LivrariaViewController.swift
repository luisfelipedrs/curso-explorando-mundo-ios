//
//  ViewController.swift
//  LearningTask-7.3
//
//  Created by rafael.rollo on 16/05/2022.
//

import UIKit

class LivrariaViewController: UICollectionViewController {
    
    var livrosApi: LivrosAPI?
    
    var livros: [Livro]?

    override func viewDidLoad() {
        super.viewDidLoad()
        applyTheme()
        // Do any additional setup after loading the view.
        carregaLivros()
    }
    
    func carregaLivros() {
        livros = livrosApi?.carregaLivros()
    }
}

// MARK: - UICollectionViewDataSource implementations
extension LivrariaViewController {
    
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return livros!.count
    }
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "LivrariaViewCell", for: indexPath) as? LivrariaViewCell else {
            fatalError("não foi possível instanciar uma célula")
        }
        let livro = livros![indexPath.row]
        cell.setup(livro)
        return cell
    }
    
    override func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        guard let header = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "LivrariaHeaderView", for: indexPath) as? LivrariaHeaderView else {
            fatalError("não foi possível instanciar um erro")
        }
        return header
    }
}

// MARK: - UICollectionViewDelegate implementations
extension LivrariaViewController {
    
    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
    }
}

// MARK: - UICollectionViewFlowLayout implementations
extension LivrariaViewController: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        guard let flowLayout = collectionViewLayout as? UICollectionViewFlowLayout else {
            fatalError("não foi possível instanciar um flowLayout")
        }
        
        let margins = flowLayout.sectionInset
        let spacing = flowLayout.minimumInteritemSpacing
        let itemsPerRow: CGFloat = 2
        let labelHeight: CGFloat = 48
        
        let minimumSpacing = collectionView.bounds.width - (margins.left + margins.right) - spacing * (itemsPerRow - 1)
        let usableWidth = minimumSpacing / itemsPerRow
        
        return CGSize(width: usableWidth, height: usableWidth * 1.41 + labelHeight)
    }
}
