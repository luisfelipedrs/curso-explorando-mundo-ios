//
//  LivrariaHeaderView.swift
//  LearningTask-7.3
//
//  Created by Luis Felipe on 08/11/22.
//

import UIKit

class LivrariaHeaderView: UICollectionReusableView {

}
