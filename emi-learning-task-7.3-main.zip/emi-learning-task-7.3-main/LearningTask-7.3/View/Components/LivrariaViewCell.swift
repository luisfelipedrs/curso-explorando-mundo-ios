//
//  LivrariaViewCell.swift
//  LearningTask-7.3
//
//  Created by Luis Felipe on 08/11/22.
//

import UIKit

class LivrariaViewCell: UICollectionViewCell {
    
    @IBOutlet weak var livroLabel: UILabel!
    @IBOutlet weak var livroImageView: UIImageView!
    
    func setup(_ livro: Livro) {
        livroLabel.text = livro.titulo
        livroImageView.image = UIImage(named: livro.titulo)
    }
}
