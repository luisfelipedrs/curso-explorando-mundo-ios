//
//  ConstraintHelpers+UIView.swift
//  LearningTask-8.1
//
//  Created by Luis Felipe on 05/05/23.
//

import UIKit

extension UIView {
    
    /// Restringe largura e altura do seu componente View Code de acordo com o tamanho desejado
    ///
    /// - Parameters:
    ///   - size: o tamanho desejado para o componente View Code
    func constrainSize(to size: CGSize) {
        let constraints = [
            self.widthAnchor.constraint(equalToConstant: size.width),
            self.heightAnchor.constraint(equalToConstant: size.height)
        ]
        
        NSLayoutConstraint.activate(constraints)
    }
}
