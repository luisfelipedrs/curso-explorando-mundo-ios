//
//  ViewCode.swift
//  LearningTask-8.1
//
//  Created by Luis Felipe on 05/05/23.
//

import Foundation

protocol ViewCode {
    func customizeAppearance()
    func addSubviews()
    func addLayoutConstraints()
}

extension ViewCode {
    func customizeAppearance() {}
    func addSubviews() {}
    func addLayoutConstraints() {}
    
    func setup() {
        customizeAppearance()
        addSubviews()
        addLayoutConstraints()
    }
}
