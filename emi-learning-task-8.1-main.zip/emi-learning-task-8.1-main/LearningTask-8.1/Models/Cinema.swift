//
//  Cinema.swift
//  LearningTask-8.1
//
//  Created by rafael.rollo on 10/06/2022.
//

import Foundation

struct Cinema {
    let name: String
    let favorite: Bool
}
