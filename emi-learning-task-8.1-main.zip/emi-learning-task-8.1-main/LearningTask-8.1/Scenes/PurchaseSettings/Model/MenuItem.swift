//
//  MenuItem.swift
//  LearningTask-8.1
//
//  Created by Luis Felipe on 09/11/22.
//

import Foundation

enum MenuItem: String, CaseIterable {
    case seatChoices = "Escolha de assento"
    case ticketTypes = "Tipos de bilhetes"
    case snacks = "Adicionar pipoca ao pedido"
    case paymentMethod = "Forma de pagamento"
}
